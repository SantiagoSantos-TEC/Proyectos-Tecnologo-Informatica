#ifndef PROTOTIPOS_H
#define PROTOTIPOS_H
#define MINAS 16

//PROTOTIPOS PARA FUNCIONES2.
typedef struct{
	int dia;
	int mes;
	int anio;
}fecha;

typedef struct {
	int ci[8];
	char nombre[15]={' '};
	char apellido[15]={' '};
	fecha nacimiento;
	char alias[15]={' '};
	char activo;
	int partidas_ganadas=0;
	int partidas_perdidas=0;
	int partidas_abandonadas=0;
}jugador;

void bienvenida(); //MENSAJE DE BIEVENIDA E INSTRUCCIONES.
void tablaInicializada(char tabla[8][8]); //INICIALIZAMOS EL TABLERO CON ?.
void tableroBomba(char tablaB[8][8]); //GENERAMOS EL TABLERO CON LAS BOMBAS.
void generarMinas(char tablaB[8][8], int fila_indice, int columna_indice); // FUNCION PARA GENERAR LAS MINAS EN EL TABLERO.
void colocarNumeros(char tablaB[8][8]); // PUNCION PARA COLOCAR LOS NUMEROS EN LOS ESPACIOS SIN BOMBAS. 
void bombas(char tablaB[8][8], int fila_indice, int columna_indice); // FUNCION PARA GENERAR LAS MINAS Y COLOCAR LOS NUMEROS.
void mostrarTabla(char tabla[8][8], bool mostrarBombas = false); //MUESTRA LA TABLA.
int contarMarcadasAdyacentes(char tabla[8][8], int fila, int columna); // FUNCION PARA CONTAR LAS CASILLAS MARCADAS ADYACENTES.
void accion(char tabla[8][8], char tablaB[8][8], int &perdiste, int &primera_jugada, int &marcadas_totales, jugador listajugador[], int i, const char alias[]); //ACCIONES QUE SE PUEDEN TOMAR EN EL JUEGO.
bool ganaste(char tabla[8][8], char tablaB[8][8], int &primera_jugada, int &perdiste, int &marcadas_totales, jugador listajugador[], int i, char alias[15]); //FUNCI�N BOOLEANA QUE DA V SI GANAS Y F SI NO GANASTE.
void mostrarBombas(char tablaB[8][8]);			//RAZONES DE TESTEO
void revelarCasillasCero(char tabla[8][8], char tablaB[8][8], int fila, int columna);
void revelarCasilla(char tabla[8][8], char tablaB[8][8], int fila, int columna);



//FUNCION LA CUAL TE PIDE EL INGRESO DE UN NUMERO PARA ELEGIR.
int ingresaOpcion();

//MENU CON OPCIONES NUMERADAS
void menu();

//MENU DEL SUBMENU DE INGRESO DE JUGADOR.
void menun();

//PROCEDIMIENTO DE GESTION DE USUARIO
void gestiondeusuario(jugador listajugador[], int &i);

//PROCEDIMIENTO CON LAS OPCIONES DE INGRESO DE JUGADOR.
void altadejugador(jugador listajugador[], int &i);

//PROCEDIMIENTO DE INGRESO DE CI.
void ingresoCI(int ci[]);

//FUNCION BOOLEADA QUE VERIFICA LA CI.
bool verificarCI(int ci[]);

//PROCEDIMIENTO QUE PIDE EL INGRESO DE TU NOMBRE.
void ingresoNombre(char nombre[]);

//PROCEDIMIENTO QUE PIDE EL INGRESO DE TU APELLIDO.
void ingresoApellido(char apellido[]);

//PROCEDIMIENTO QUE PIDE EL INGRESO DE TU FECHA DE NACIMIENTO.
void ingresoNacimiento(fecha &nacimiento);

//ESTRUCTURA CON LAS VARIABLES DE FECHA.
fecha devuelvoFecha();

//FUNCION BOOLEANA QUE VERIFICA SI LA FECHA INGRESADA ES CORRECTA.
bool esFechaValida(int dia, int mes, int anio);

//PROCEDIMIENTO QUE PIDE INGRESO DE ALIAS.
void ingresoAlias(char alias[]);

//FUNCION QUE VERIFICA EL ALIAS.
int verificarAliasUnico(jugador listajugador[], int numJugadores, char alias[]);

//FUNCION QUE BUSCA ALIAS.
int buscaralias(jugador listajugador[], int i, const char auxalias[]);

//PROCEDIMIENTO QUE MUESTRA ALIAS.
void muestroalias(char alias[]);

//PROCEDIMIENTO QUE DA DE BAJA AL JUGADOR.
void bajadejugador();

//FUNCION BOOLEANA QUE PERMITE LA MODIFICACION DE JUGADOR.
bool modificaciondejugador(jugador listajugador[], int i, const char alias[]);

//PROCEDIMIENTO DE MENU DE CONSULTA.
void menucons();

//PROCEDIMIENTO CON OPCIONES PARA LA CONSULTA.
void consultas(jugador listajugador[], int i);

int ciToInt(int ci[8]);

void sumarganar(jugador listajugador[],int i, const char alias[]);

void sumarperder(jugador listajugador[],int i, const char alias[]);

void sumarabandonar(jugador listajugador[],int i, const char alias[]);

//PROCEDIMIENTO CON EL LISTADO DE JUGADORES.
void listadojugadores(jugador listajugador[], int i);

//PROCEDIMIENTO CON EL LISTADO DE TODAS LAS PARTIDAS.
void listadotodaspartidas(jugador listajugador[], int i);

//PROCEDIMIENTO DE LISTADO DE PARTIDAS DE JUGADOR.
void listadopartidasjugador();

//PROCEDIMIENTO DE LISTADO DE PARTIDAS POR FECHA.
void listadopartidasfecha();

//FUNCION BOOLEANA QUE PERMITE JUGAR.
bool jugar(jugador listajugador[], int i, char tabla[8][8], char tablaB[8][8], int primera_jugada, int marcadas_totales);

//PROCEDIMIENTO QUE REINICIA EL JUEGO.
void reiniciarJuego(char tabla[8][8], char tablaB[8][8]);

//PROCEDIMIENTO QUE AYUDA A REINICIAR EL JUEGO.
void reiniciarFlags(int &perdiste, int &primera_jugada, int &marcadas_totales);

//PROCEDIMIENTO DE SALIR.
void salir();

#endif
