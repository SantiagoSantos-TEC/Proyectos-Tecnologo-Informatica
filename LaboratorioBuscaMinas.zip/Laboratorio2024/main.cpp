#include<iostream>
#include<stdio_ext.h>
#include <string.h>
using namespace std;
#include "PROTOTIPOS.h"
#include <time.h>	//A�ADIR LIBRERIA "time.h (EN CASO DE ESTAR EN WINDOWS)"


int main (int argc, char *argv[]) {

srand(time(NULL));


char tabla[8][8], tablaB[8][8];
int perdiste=0;
int primera_jugada = 1;
int marcadas_totales = 0;
int opcion;
jugador listajugador[10];
int i;
i=0;


menu();
opcion=ingresaOpcion();
while(opcion!=4){
	
	//mostrarBombas(tablaB); //DESCOMENTAR EN CASO DE QUERER HACER TRAMPA.
	
	switch(opcion){
	case 1:
		gestiondeusuario(listajugador, i);
		break;
	case 2:
		consultas(listajugador, i);
		break;
	case 3:
		char alias[15];
		
		if (jugar(listajugador, i, tabla, tablaB, primera_jugada, marcadas_totales)){
			ingresoAlias(alias);
			bienvenida();
			tablaInicializada(tabla);
			tablaInicializada(tablaB);
			mostrarTabla(tabla);
			do {
				
				//mostrarBombas(tablaB); //DESCOMENTAR EN CASO DE QUERER HACER TRAMPA.
				accion(tabla, tablaB, perdiste, primera_jugada, marcadas_totales, listajugador, i, alias);
			} while (perdiste==0 && !ganaste(tabla, tablaB, primera_jugada, perdiste, marcadas_totales, listajugador, i, alias));
			
			if (perdiste) {
				
				reiniciarJuego(tabla, tablaB);
				reiniciarFlags(perdiste, primera_jugada, marcadas_totales);
			}
		}
		break;
	case 4:
		salir();
		break;
	}
	menu();
	opcion=ingresaOpcion();

}
salir();
return 0;
}
