#include<iostream>
#include<stdio_ext.h>
#include <string.h>
using namespace std;
#include "PROTOTIPOS.h"
//MENSAJE DE BIEVENIDA E INSTRUCCIONES.

void bienvenida(){
	printf("BIENVENIDO JUGADOR\n\n");
	printf("En este juego existen 3 tipos de movimientos:\n");
	printf("\nE->Explorar(Revela lo que hay en esa casilla)\n\nM->Marcar(Marca una casilla sospechosa)\n\nB->Buscar(Revela lo que se encuentra en todas las casillas no exploradas\nadyacentes a la misma)\n\nR->Rendirse(Seguido de 2 coordenadas validas cualquiera, hara que el jugador se\nrinda y se guardara como abandono)\n\n");
	printf("===========================================================================\n");
	printf("\nPara indicar tu jugada digitas tu opcion (E, M o B) seguido de un espacio y\nluego las coordenadas de dicha casilla.");
	printf("\nPor ejemplo: E AD");
	printf("\n\nLas casillas sospechosas son indicadas con una X\ny las casillas con bombas se indican con una B\n\n");
	printf("Para ganar debera marcar todas las minas.\n\nEn caso de querer quitar una marca solo tiene que volver a ejecutar\nel comando de marcar en la misma casilla.\n\nEn caso de querer buscar en una casilla con numero, el numero en esta casilla debera coincidir\ncon el numero de marcas adyacentes a esta casilla.");
	printf("\n\nPrecione ENTER para continuar");
	getchar();
	system("clear");  //CAMBIAR "cls" POR "cls" (EN CASO DE ESTAR EN WINDOWS).
}
	
	//INICIALIZAMOS EL TABLERO CON ?.
	
void tablaInicializada(char tabla[8][8]){
	
	for(int i = 0; i < 8; i++) {
		for(int j = 0; j < 8; j++) {
			tabla[i][j] = '?';
		}
	}
}
	
	//GENERAMOS EL TABLERO CON LAS BOMBAS.
	
void tableroBomba(char tablaB[8][8]){
	
	// IMPRIMIR EL TABLERO.
	//printf(" ");
	for(int i = 0; i < 8; i++) {
		//printf("%c ", 65 + i); // IMPRIMIR EL NUMERO DE FILA
	}
	//printf("\n");
	
	for(int i = 0; i < 8; i++) {
		//printf("%c", 65 + i); // IMPRIMIR EL NUMERO DE COLUMNA
		
		for(int j = 0; j < 8; j++) {
			//printf("%c ",tablaB[i][j]); // MOSTRAR EL CONTENIDO DE LA POSICION
		}
		//printf("\n");
	}
}
	
	//CARGAMOS LAS BOMBAS EN EL TABLERO.
	
	// FUNCION PARA GENERAR LAS MINAS EN EL TABLERO.
	void generarMinas(char tablaB[8][8], int fila_indice, int columna_indice) {
		int minas_generadas = 0;
		
		while (minas_generadas < MINAS) {
			int fila = rand() % 8;
			int columna = rand() % 8;
			
			// EVITAR QUE LA PRIMERA JUGADA TENGA UNA BOMBA.
			if (fila != fila_indice || columna != columna_indice) {
				if (tablaB[fila][columna] != 'B') {
					tablaB[fila][columna] = 'B';
					minas_generadas++;
				}
			}
		}
	}
	
	// FUNCION PARA COLOCAR LOS NUMEROS EN LOS ESPACIOS SIN BOMBAS.
	void colocarNumeros(char tablaB[8][8]) {
		for (int f = 0; f < 8; f++) {
			for (int c = 0; c < 8; c++) {
				if (tablaB[f][c] != 'B') {
					int bombas = 0;
					// VERIFICAR CASILLAS ADYACENTES.
					for (int i = -1; i <= 1; i++) {
						for (int j = -1; j <= 1; j++) {
							if (f + i >= 0 && f + i < 8 && c + j >= 0 && c + j < 8 && tablaB[f + i][c + j] == 'B') {
								bombas++;
							}
						}
					}
					//CONTROLAR QUE SE GENEREN NUMEROS Y NO CARACTERES AL AZAR.
					tablaB[f][c] = '0' + bombas;
				}
			}
		}
	}
	
	// FUNCION PARA GENERAR LAS MINAS Y COLOCAR LOS NUMEROS.
	void bombas(char tablaB[8][8], int fila_indice, int columna_indice) {
		generarMinas(tablaB, fila_indice, columna_indice);
		colocarNumeros(tablaB);
	}
	
	//MUESTRA LA TABLA.
	void mostrarTabla(char tabla[8][8], bool mostrarBombas){
		printf(" ");
		for(int i = 0; i < 8; i++) {
			printf("%c ", 65 + i); // IMPRIMIR EL NUMERO DE FILA.
		}
		printf("\n");
		
		for(int i = 0; i < 8; i++) {
			printf("%c", 65 + i); // IMPRIMIR EL NUMERO DE COLUMNA.
			
			for(int j = 0; j < 8; j++) {
				if (tabla[i][j] == 'B' && mostrarBombas) {
					printf("B "); // MOSTRAR LAS BOMBAS.
				} else {
					printf("%c ",tabla[i][j]); // MOSTRAR EL CONTENIDO DE LA POSICION.
				}
			}
			printf("\n");
		}
	}
	
// FUNCION PARA CONTAR LAS CASILLAS MARCADAS ADYACENTES.
	
	
int contarMarcadasAdyacentes(char tabla[8][8], int fila, int columna) {
		int marcadas = 0;
		// VERIFICAR LAS 8 POSICIONES ADYACENTES.
		for (int i = fila - 1; i <= fila + 1; i++) {
			for (int j = columna - 1; j <= columna + 1; j++) {
				// VERIFICAR SI LA POSICION ESTA DENTRO DE LOS LIMITES DEL TABLERO.
				if (i >= 0 && i < 8 && j >= 0 && j < 8) {
					// VERIFICAR SI LA CASILLA ESTA MARCADA COMO SOSPECHOSA.
					if (tabla[i][j] == 'X') {
						marcadas++;
					}
				}
			}
		}
		return marcadas;
	}
	
	
//ACCIONES QUE SE PUEDEN TOMAR EN EL JUEGO.
void accion(char tabla[8][8], char tablaB[8][8], int &perdiste, int &primera_jugada, int &marcadas_totales, jugador listajugador[], int i, const char alias[]) {
	char accion, fila, columna;
	printf("\n");
	do {
		scanf(" %c %c%c", &accion, &fila, &columna);
		__fpurge(stdin);
		// VERIFICAR SI LA ACCION ESTA DENTRO DEL RANGO PERMITIDO.
		if ((accion == 'E' || accion == 'B' || accion == 'M' || accion == 'R') &&
			(fila >= 'A' && fila <= 'H') &&
			(columna >= 'A' && columna <= 'H')) {
			break; 
		} else {
				printf("Error: La accion debe ser E, B, M o R, y la fila y columna deben estar entre A y H.\n");
			}
	__fpurge(stdin);	
	} while (true);
	
	int fila_indice, columna_indice;
	
	switch (accion) {
	case 'B': // Accion para buscar
		getchar();
		fila_indice = fila - 'A';
		columna_indice = columna - 'A';
		
		// Verificar que la casilla haya sido explorada
		if (tabla[fila_indice][columna_indice] >= '0' && tabla[fila_indice][columna_indice] <= '8') {
			// Verificar que la cantidad de marcas adyacentes coincidan con el numero en dicha casilla
			int marcas_adyacentes = contarMarcadasAdyacentes(tabla, fila_indice, columna_indice);
			if (marcas_adyacentes == tabla[fila_indice][columna_indice] - '0') {
				// Realizar la accion de buscar en las casillas adyacentes
				bool perdio = false; // Variable para controlar si el jugador pierde
				for (int i = fila_indice - 1; i <= fila_indice + 1; ++i) {
					for (int j = columna_indice - 1; j <= columna_indice + 1; ++j) {
						if (i >= 0 && i < 8 && j >= 0 && j < 8 && tabla[i][j] == '?') {
							if (tablaB[i][j] == '0') {
								revelarCasillasCero(tabla, tablaB, i, j);
							} else if (tablaB[i][j] == 'B') {
								perdio = true; // El jugador pierde si encuentra una bomba
							} else {
								tabla[i][j] = tablaB[i][j];
							}
						}
					}
				}
				if (perdio) {
					perdiste=1;
				} else {
					mostrarTabla(tabla);
				}
			} else {
				printf("\nNo se puede buscar en esta casilla. Cantidad de marcas adyacentes incorrecta.\n");
			}
		} else if (tabla[fila_indice][columna_indice] == '0') {
			// Si la casilla es '0', se puede realizar la accion de buscar directamente
			revelarCasillasCero(tabla, tablaB, fila_indice, columna_indice);
			mostrarTabla(tabla);
		} else {
			printf("\nNo se puede buscar en esta casilla.\n");
		}
		break;
		
	case 'E': // Accion para explorar
		getchar();
		fila_indice = fila - 'A';
		columna_indice = columna - 'A';
		if (tabla[fila_indice][columna_indice] == '?') {
			// SI ES LA PRIMERA JUGADA, GENERAR LAS BOMBAS LUEGO DE ESTA JUGADA.
			if (primera_jugada) {
				bombas(tablaB, fila_indice, columna_indice);
				primera_jugada = 0;
			}
			if (tablaB[fila_indice][columna_indice] == '0') {
				// Realizar una busqueda en profundidad para revelar solo las casillas adyacentes una a una.
				for (int i = fila_indice - 1; i <= fila_indice + 1; ++i) {
					for (int j = columna_indice - 1; j <= columna_indice + 1; ++j) {
						if (i >= 0 && i < 8 && j >= 0 && j < 8 && tabla[i][j] == '?') {
							tabla[i][j] = tablaB[i][j];
						}
					}
				}
			} else {
				tabla[fila_indice][columna_indice] = tablaB[fila_indice][columna_indice];
			}
			mostrarTabla(tabla);
		} else {
			printf("Formato de jugada erroneo\n");
		}
		if (tabla[fila_indice][columna_indice] == 'B') {
			perdiste=1;
		}
		break;
		
	case 'M':
		getchar();
		fila_indice = fila - 'A';
		columna_indice = columna - 'A';
		// CONTROLAR QUE NO PUEDA COLOCAR MARCAS EN CASILLAS EXPLORADAS.
		if (tabla[fila_indice][columna_indice] != '?' && tabla[fila_indice][columna_indice] != 'X') {
			printf("\nFormato de jugada erroneo\n");
			break;
		}
		
		if (tabla[fila_indice][columna_indice] == 'X') {
			tabla[fila_indice][columna_indice] = '?';
			mostrarTabla(tabla);
			marcadas_totales--;
			break;
		}
		// CONTROLAR QUE NO HAYAN MA�S MARCAS QUE MINAS.
		if (marcadas_totales < MINAS) {
			if (tabla[fila_indice][columna_indice] == '?') {
				tabla[fila_indice][columna_indice] = 'X';
				mostrarTabla(tabla);
				marcadas_totales++;
			} 
		} else {
			printf("\nYa has marcado el limite maximo de casillas.\n");
		}
		break;
		
	case 'R': // Acci�n para rendirse
		perdiste = 2; // Indicar rendisrse
		printf("\n TE RENDISTE !!!!. No te preocupes, se guardar� como abandono.\n\n");
		getchar();
		system("clear");
		// Aumentar el contador de partidas abandonadas del jugador actual
		sumarabandonar(listajugador, i, alias);
		break;
		
	default:
		printf("\nFormato de jugada erroneo\n");
		break;
	}
	// Verificar si el jugador ha perdido (incluyendo rendirse)
	if (perdiste == 1) {
		mostrarTabla(tablaB, true); // MOSTRAR LAS BOMBAS CUANDO EL JUGADOR PIERDE.
		printf("\n PERDISTE !!!! Suerte la proxima, se nota que la necesitas\n\n");
		// Aumentar el contador de partidas perdidas del jugador actual
		sumarperder(listajugador, i, alias);
		getchar();
		system("clear");
	}
}






//FUNCI�N BOOLEANA QUE DA V SI GANAS Y F SI NO GANASTE.
bool ganaste(char tabla[8][8], char tablaB[8][8], int &primera_jugada, int &perdiste, int &marcadas_totales, jugador listajugador[], int i, char alias[15]) {
	if (primera_jugada) {
		return false; // SI ES LA PRIMERA JUGADA EL JUGADOR NO GANARA AUTOMATICAMENTE.
	}
	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 8; j++) {
			if ((tabla[i][j] == 'X' && tablaB[i][j] != 'B') || (tabla[i][j] != 'X' && tablaB[i][j] == 'B')) {
				return false; // SI HAY ALGUNA 'X' QUE NO COINCIDE CON 'B' O VOCEVERSA, NO HA GANADO.
			}
		}
	}
	printf("Pfff... fue pura suerte, la proxima no sera tan facil.\n");
	getchar();
	system("clear");
	// Aumentamos el contador de partidas ganadas del jugador actual
	sumarganar(listajugador,i, alias);
	reiniciarJuego(tabla, tablaB);
	reiniciarFlags(perdiste, primera_jugada, marcadas_totales);
	return true; // SI TODAS LAS 'X' COINCIDEN CON 'B', HA GANADO.
}


	//ESTE VOID ES POR RAZONES DE TESTEO, NO DEBE CAER EN LAS MANOS EQUIVOCADAS.

void mostrarBombas(char tablaB[8][8]) {
	printf(" ");
	for (int i = 0; i < 8; i++) {
		printf("%c ", 65 + i); // IMPRIMIR EL NUMERO DE FILA.
	}
	printf("\n");
	
	for (int i = 0; i < 8; i++) {
		printf("%c", 65 + i); // IMPRIMIR EL NUMERO DE COLUMNA.
		
		for (int j = 0; j < 8; j++) {
			if (tablaB[i][j] == 'B') {
				printf("B "); 
			} else {
				printf("? "); 
			}
		}
		printf("\n");
	}
}

//PROCEDIMIENTO QUE REVELA LAS CASILLAS CON CERO
void revelarCasillasCero(char tabla[8][8], char tablaB[8][8], int fila, int columna) {
	if (fila < 0 || fila >= 8 || columna < 0 || columna >= 8 || tabla[fila][columna] != '?') {
		return;
	}
	
	tabla[fila][columna] = tablaB[fila][columna];
	
	// Revelar las casillas adyacentes, incluidas las diagonales, solo si la casilla explorada es un 0
	for (int i = fila - 1; i <= fila + 1; ++i) {
		for (int j = columna - 1; j <= columna + 1; ++j) {
			if (i >= 0 && i < 8 && j >= 0 && j < 8 && (i != fila || j != columna)) {
				if (tablaB[i][j] == '0') {
					revelarCasillasCero(tabla, tablaB, i, j);
				} else {
					tabla[i][j] = tablaB[i][j];
				}
			}
		}
	}
}

//PROCEDIMIENTO QUE REVELA CASILLAS.
void revelarCasilla(char tabla[8][8], char tablaB[8][8], int fila, int columna) {
	if (fila < 0 || fila >= 8 || columna < 0 || columna >= 8 || tabla[fila][columna] != '?') {
		return;
	}
	
	tabla[fila][columna] = tablaB[fila][columna];
	if (tablaB[fila][columna] == '0') {
		revelarCasillasCero(tabla, tablaB, fila, columna);
	}
}




