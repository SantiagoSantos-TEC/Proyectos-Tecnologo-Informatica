#include "Compra.h"
#include "Cliente.h"
#include "Producto.h"
#include <stdexcept>

Compra::Compra(string fecha, float monto, Cliente* cliente) :
    fecha(fecha), monto(monto), cliente(cliente) {}

void Compra::agregarProducto(Producto* p, int cantidad) {
    // Verificar si el producto ya está en la compra
    for (auto& item : productos) {
        if (item.first == p) {
            throw invalid_argument("El producto ya está en la compra");
        }
    }
    
    productos.push_back(make_pair(p, make_pair(cantidad, false)));
}

void Compra::marcarEnviado(Producto* p) {
    for (auto& item : productos) {
        if (item.first == p) {
            item.second.second = true;
            return;
        }
    }
    throw invalid_argument("Producto no encontrado en la compra");
}

DtCompra Compra::getDt() {
    DtCompra dt;
    dt.cliente = cliente->getNickname();
    dt.fecha = fecha;
    dt.monto = monto;
    
    for (auto& item : productos) {
        dt.productos.push_back(make_pair(item.first->getCodigo(), item.second.first));
    }
    
    return dt;
}

string Compra::getFecha() {
    return fecha;
}

Cliente* Compra::getCliente() {
    return cliente;
}

bool Compra::tieneProductoPendiente(Producto* p) {
    for (auto& item : productos) {
        if (item.first == p && !item.second.second) {
            return true;
        }
    }
    return false;
}