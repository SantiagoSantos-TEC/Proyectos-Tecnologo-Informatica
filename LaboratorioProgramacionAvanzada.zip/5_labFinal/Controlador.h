#ifndef CONTROLADOR_H
#define CONTROLADOR_H

#include "IControlador.h"
#include "Usuario.h"
#include "Producto.h"
#include "Promocion.h"
#include "Compra.h"
#include "Comentario.h"
#include <map>

class Controlador : public IControlador {
private:
    static Controlador* instancia;
    map<string, Usuario*> usuarios;
    map<string, Producto*> productos;
    map<string, Promocion*> promociones;
    vector<Compra*> compras;
    vector<Comentario*> comentarios;
    
    Controlador(); // Constructor privado para singleton
    
public:
    static Controlador* getInstancia();
    
    void altaUsuario(DtUsuario, string tipo, string extra1 = "", string extra2 = "") override;
    vector<DtUsuario> listarUsuarios() override;
    DtUsuario expedienteUsuario(string nickname) override;
    
    void altaProducto(DtProducto, string vendedorNick) override;
    vector<DtProducto> listarProductos() override;
    DtProducto consultarProducto(string codigo) override;
    
    void crearPromocion(DtPromocion, string vendedorNick) override;
    vector<DtPromocion> listarPromociones() override;
    DtPromocion consultarPromocion(string nombre) override;
    
    void realizarCompra(DtCompra) override;
    void enviarProducto(string vendedorNick, string productoCodigo, string clienteNick, string fechaCompra) override;
    
    void dejarComentario(string autor, string producto, string texto, string comentarioPadre = "") override;
    void eliminarComentario(string autor, string producto, string fecha) override;
    vector<DtComentario> listarComentariosProducto(string producto) override;
};

#endif

