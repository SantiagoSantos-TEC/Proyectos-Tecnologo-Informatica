#ifndef VENDEDOR_H
#define VENDEDOR_H

#include "Usuario.h"
#include "DtClasses.h"
#include <vector>

class Producto;
class Promocion;

class Vendedor : public Usuario {
private:
    string rut;
    vector<Producto*> productos;
    vector<Promocion*> promociones;
    
public:
    Vendedor(string nickname, string password, string fechaNacimiento, string rut);
    DtUsuario getDt() override;
    
    void agregarProducto(Producto* p);
    void agregarPromocion(Promocion* p);
    
    vector<Producto*> getProductos();
    vector<Promocion*> getPromociones();
};

#endif
