#include "Comentario.h"
#include "Usuario.h"
#include "Producto.h"
#include <algorithm>

Comentario::Comentario(string texto, string fecha, Usuario* autor, Producto* producto, Comentario* padre) :
    texto(texto), fecha(fecha), autor(autor), producto(producto), padre(padre) {
    if (padre != nullptr) {
        padre->agregarRespuesta(this);
    }
}

Comentario::~Comentario() {
    for (auto& respuesta : respuestas) {
        delete respuesta;
    }
}

void Comentario::agregarRespuesta(Comentario* c) {
    respuestas.push_back(c);
}

DtComentario Comentario::getDt() {
    DtComentario dt;
    dt.autor = autor->getNickname();
    dt.texto = texto;
    dt.fecha = fecha;
    
    for (auto& respuesta : respuestas) {
        dt.respuestas.push_back(respuesta->getDt());
    }
    
    return dt;
}

string Comentario::getFecha() {
    return fecha;
}

Usuario* Comentario::getAutor() {
    return autor;
}

Producto* Comentario::getProducto() {
    return producto;
}
