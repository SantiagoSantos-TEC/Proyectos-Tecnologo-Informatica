#ifndef COMPRA_H
#define COMPRA_H

#include "DtClasses.h"
#include <vector>
#include <string>

class Cliente;
class Producto;

class Compra {
private:
    string fecha;
    float monto;
    Cliente* cliente;
    vector<pair<Producto*, pair<int, bool>>> productos; // Producto, cantidad, enviado
    
public:
    Compra(string fecha, float monto, Cliente* cliente);
    
    void agregarProducto(Producto* p, int cantidad);
    void marcarEnviado(Producto* p);
    
    DtCompra getDt();
    string getFecha();
    Cliente* getCliente();
    bool tieneProductoPendiente(Producto* p);
};

#endif
