#include "Controlador.h"
#include "Cliente.h"
#include "Vendedor.h"
#include "Producto.h"
#include "Promocion.h"
#include "Compra.h"
#include "Comentario.h"
#include <algorithm>
#include <stdexcept>

Controlador* Controlador::instancia = nullptr;

Controlador::Controlador() {
}

Controlador* Controlador::getInstancia() {
    if (instancia == nullptr) {
        instancia = new Controlador();
    }
    return instancia;
}

void Controlador::altaUsuario(DtUsuario dt, string tipo, string extra1, string extra2) {
    if (usuarios.find(dt.nickname) != usuarios.end()) {
        throw invalid_argument("Ya existe un usuario con ese nickname");
    }
    
    Usuario* u;
    if (tipo == "cliente") {
        DtCliente& dtc = static_cast<DtCliente&>(dt);
        u = new Cliente(dtc.nickname, extra1, dtc.fechaNacimiento, dtc.direccion, dtc.ciudad);
    } else {
        u = new Vendedor(dt.nickname, extra1, dt.fechaNacimiento, extra2);
    }
    
    usuarios[dt.nickname] = u;
}

vector<DtUsuario> Controlador::listarUsuarios() {
    vector<DtUsuario> result;
    for (auto& pair : usuarios) {
        result.push_back(pair.second->getDt());
    }
    return result;
}

DtUsuario Controlador::expedienteUsuario(string nickname) {
    if (usuarios.find(nickname) == usuarios.end()) {
        throw invalid_argument("Usuario no encontrado");
    }
    return usuarios[nickname]->getDt();
}

void Controlador::altaProducto(DtProducto dt, string vendedorNick) {
    if (productos.find(dt.codigo) != productos.end()) {
        throw invalid_argument("Ya existe un producto con ese código");
    }
    
    if (usuarios.find(vendedorNick) == usuarios.end() || 
        dynamic_cast<Vendedor*>(usuarios[vendedorNick]) == nullptr) {
        throw invalid_argument("Vendedor no válido");
    }
    
    Vendedor* v = dynamic_cast<Vendedor*>(usuarios[vendedorNick]);
    Producto* p = new Producto(dt.codigo, dt.nombre, dt.precio, dt.stock, 
                             dt.descripcion, dt.categoria, v);
    productos[dt.codigo] = p;
}

vector<DtProducto> Controlador::listarProductos() {
    vector<DtProducto> result;
    for (auto& pair : productos) {
        result.push_back(pair.second->getDt());
    }
    return result;
}

DtProducto Controlador::consultarProducto(string codigo) {
    if (productos.find(codigo) == productos.end()) {
        throw invalid_argument("Producto no encontrado");
    }
    return productos[codigo]->getDt();
}

void Controlador::crearPromocion(DtPromocion dt, string vendedorNick) {
    if (promociones.find(dt.nombre) != promociones.end()) {
        throw invalid_argument("Ya existe una promoción con ese nombre");
    }
    
    if (usuarios.find(vendedorNick) == usuarios.end() || 
        dynamic_cast<Vendedor*>(usuarios[vendedorNick]) == nullptr) {
        throw invalid_argument("Vendedor no válido");
    }
    
    Vendedor* v = dynamic_cast<Vendedor*>(usuarios[vendedorNick]);
    Promocion* p = new Promocion(dt.nombre, dt.descripcion, dt.fechaVencimiento, v);
    
    for (auto& item : dt.productos) {
        if (productos.find(item.first) == productos.end()) {
            delete p;
            throw invalid_argument("Producto no encontrado: " + item.first);
        }
        p->agregarProducto(productos[item.first], item.second);
    }
    
    promociones[dt.nombre] = p;
}


