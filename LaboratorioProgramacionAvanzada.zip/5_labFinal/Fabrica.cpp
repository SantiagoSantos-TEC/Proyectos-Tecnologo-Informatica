#include "Fabrica.h"
#include "Controlador.h"

IControlador* Fabrica::getIControlador() {
    return Controlador::getInstancia();
}

