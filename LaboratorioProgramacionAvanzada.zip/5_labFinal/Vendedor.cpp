#include "Vendedor.h"
#include "Producto.h"
#include "Promocion.h"

Vendedor::Vendedor(string nickname, string password, string fechaNacimiento, string rut) : 
    Usuario(nickname, password, fechaNacimiento), rut(rut) {}

DtUsuario Vendedor::getDt() {
    DtVendedor dt;
    dt.nickname = nickname;
    dt.fechaNacimiento = fechaNacimiento;
    dt.rut = rut;
    return dt;
}

void Vendedor::agregarProducto(Producto* p) { productos.push_back(p); }
void Vendedor::agregarPromocion(Promocion* p) { promociones.push_back(p); }

vector<Producto*> Vendedor::getProductos() { return productos; }
vector<Promocion*> Vendedor::getPromociones() { return promociones; }