#include "Promocion.h"
#include "Producto.h"
#include "Vendedor.h"
#include <stdexcept>

Promocion::Promocion(string nombre, string descripcion, string fechaVencimiento, Vendedor* vendedor) :
    nombre(nombre), descripcion(descripcion), fechaVencimiento(fechaVencimiento), vendedor(vendedor) {
    vendedor->agregarPromocion(this);
}

void Promocion::agregarProducto(Producto* p, int cantidadMinima) {
    // Verificar si el producto ya está en la promoción
    for (auto& item : productos) {
        if (item.first == p) {
            throw invalid_argument("El producto ya está en la promoción");
        }
    }
    
    productos.push_back(make_pair(p, cantidadMinima));
}

DtPromocion Promocion::getDt() {
    DtPromocion dt;
    dt.nombre = nombre;
    dt.descripcion = descripcion;
    dt.fechaVencimiento = fechaVencimiento;
    
    for (auto& item : productos) {
        dt.productos.push_back(make_pair(item.first->getCodigo(), item.second));
    }
    
    return dt;
}

string Promocion::getNombre() {
    return nombre;
}

bool Promocion::contieneProducto(Producto* p) {
    for (auto& item : productos) {
        if (item.first == p) {
            return true;
        }
    }
    return false;
}
