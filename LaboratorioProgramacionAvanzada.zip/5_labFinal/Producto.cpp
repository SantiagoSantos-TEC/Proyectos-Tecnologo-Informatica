#include "Producto.h"
#include "Vendedor.h"
#include "Comentario.h"

Producto::Producto(string codigo, string nombre, float precio, int stock, 
                   string descripcion, Categoria categoria, Vendedor* vendedor) :
    codigo(codigo), nombre(nombre), precio(precio), stock(stock),
    descripcion(descripcion), categoria(categoria), vendedor(vendedor) {
    vendedor->agregarProducto(this);
}

string Producto::getCodigo() {
    return codigo;
}

string Producto::getNombre() {
    return nombre;
}

float Producto::getPrecio() {
    return precio;
}

int Producto::getStock() {
    return stock;
}

string Producto::getDescripcion() {
    return descripcion;
}

Categoria Producto::getCategoria() {
    return categoria;
}

Vendedor* Producto::getVendedor() {
    return vendedor;
}

DtProducto Producto::getDt() {
    DtProducto dt;
    dt.codigo = codigo;
    dt.nombre = nombre;
    dt.precio = precio;
    dt.stock = stock;
    dt.descripcion = descripcion;
    dt.categoria = categoria;
    dt.vendedor = vendedor->getNickname();
    return dt;
}

void Producto::agregarComentario(Comentario* c) {
    comentarios.push_back(c);
}

vector<Comentario*> Producto::getComentarios() {
    return comentarios;
}