#include "Cliente.h"

Cliente::Cliente(string nickname, string password, string fechaNacimiento, 
                 string direccion, string ciudad) : 
    Usuario(nickname, password, fechaNacimiento), direccion(direccion), ciudad(ciudad) {}

DtUsuario Cliente::getDt() {
    DtCliente dt;
    dt.nickname = nickname;
    dt.fechaNacimiento = fechaNacimiento;
    dt.direccion = direccion;
    dt.ciudad = ciudad;
    return dt;
}

