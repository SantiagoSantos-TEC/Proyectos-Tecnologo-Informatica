#include "Usuario.h"

Usuario::Usuario(string nickname, string password, string fechaNacimiento) : 
    nickname(nickname), password(password), fechaNacimiento(fechaNacimiento) {}

Usuario::~Usuario() {}

string Usuario::getNickname() { return nickname; }

