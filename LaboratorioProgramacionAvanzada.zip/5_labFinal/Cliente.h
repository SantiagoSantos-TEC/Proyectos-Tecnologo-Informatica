#ifndef CLIENTE_H
#define CLIENTE_H

#include "Usuario.h"
#include "DtClasses.h"

class Cliente : public Usuario {
private:
    string direccion;
    string ciudad;
    
public:
    Cliente(string nickname, string password, string fechaNacimiento, string direccion, string ciudad);
    DtUsuario getDt() override;
};

#endif
