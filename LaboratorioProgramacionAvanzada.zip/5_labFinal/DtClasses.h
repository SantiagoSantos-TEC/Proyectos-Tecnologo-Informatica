#ifndef DTCLASSES_H
#define DTCLASSES_H

#include <string>
#include <vector>
#include <ctime>

using namespace std;

enum Categoria {ROPA, ELECTRODOMESTICOS, OTROS};

struct DtUsuario {
    string nickname;
    string fechaNacimiento;
};

struct DtCliente : public DtUsuario {
    string direccion;
    string ciudad;
};

struct DtVendedor : public DtUsuario {
    string rut;
};

struct DtProducto {
    string codigo;
    string nombre;
    float precio;
    int stock;
    string descripcion;
    Categoria categoria;
    string vendedor;
};

struct DtPromocion {
    string nombre;
    string descripcion;
    string fechaVencimiento;
    vector<pair<string, int>> productos; // codigoProducto, cantidadMinima
};

struct DtCompra {
    string cliente;
    string fecha;
    float monto;
    vector<pair<string, int>> productos; // codigoProducto, cantidad
};

struct DtComentario {
    string autor;
    string texto;
    string fecha;
    vector<DtComentario> respuestas;
};

#endif

