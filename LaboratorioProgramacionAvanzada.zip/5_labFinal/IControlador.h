#ifndef ICONTROLADOR_H
#define ICONTROLADOR_H

#include "DtClasses.h"
#include <vector>

class IControlador {
public:
    virtual void altaUsuario(DtUsuario, string tipo, string extra1 = "", string extra2 = "") = 0;
    virtual vector<DtUsuario> listarUsuarios() = 0;
    virtual DtUsuario expedienteUsuario(string nickname) = 0;
    
    virtual void altaProducto(DtProducto, string vendedorNick) = 0;
    virtual vector<DtProducto> listarProductos() = 0;
    virtual DtProducto consultarProducto(string codigo) = 0;
    
    virtual void crearPromocion(DtPromocion, string vendedorNick) = 0;
    virtual vector<DtPromocion> listarPromociones() = 0;
    virtual DtPromocion consultarPromocion(string nombre) = 0;
    
    virtual void realizarCompra(DtCompra) = 0;
    virtual void enviarProducto(string vendedorNick, string productoCodigo, string clienteNick, string fechaCompra) = 0;
    
    virtual void dejarComentario(string autor, string producto, string texto, string comentarioPadre = "") = 0;
    virtual void eliminarComentario(string autor, string producto, string fecha) = 0;
    virtual vector<DtComentario> listarComentariosProducto(string producto) = 0;

};

#endif

