#ifndef PRODUCTO_H
#define PRODUCTO_H

#include "DtClasses.h"
#include <string>

class Vendedor;
class Comentario;

class Producto {
private:
    string codigo;
    string nombre;
    float precio;
    int stock;
    string descripcion;
    Categoria categoria;
    Vendedor* vendedor;
    vector<Comentario*> comentarios;
    
public:
    Producto(string codigo, string nombre, float precio, int stock, string descripcion, Categoria categoria, Vendedor* vendedor);
    
    string getCodigo();
    string getNombre();
    float getPrecio();
    int getStock();
    string getDescripcion();
    Categoria getCategoria();
    Vendedor* getVendedor();
    
    DtProducto getDt();
    
    void agregarComentario(Comentario* c);
    vector<Comentario*> getComentarios();
};

#endif
