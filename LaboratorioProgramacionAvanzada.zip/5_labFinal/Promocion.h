#ifndef PROMOCION_H
#define PROMOCION_H

#include "DtClasses.h"
#include <vector>
#include <string>

class Producto;
class Vendedor;

class Promocion {
private:
    string nombre;
    string descripcion;
    string fechaVencimiento;
    vector<pair<Producto*, int>> productos; // Producto y cantidad mínima
    Vendedor* vendedor;
    
public:
    Promocion(string nombre, string descripcion, string fechaVencimiento, Vendedor* vendedor);
    
    void agregarProducto(Producto* p, int cantidadMinima);
    DtPromocion getDt();
    
    string getNombre();
    bool contieneProducto(Producto* p);
};

#endif

