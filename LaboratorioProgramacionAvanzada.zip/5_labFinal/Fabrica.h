#ifndef FABRICA_H
#define FABRICA_H

#include "IControlador.h"

class Fabrica {
public:
    static IControlador* getIControlador();
};

#endif
