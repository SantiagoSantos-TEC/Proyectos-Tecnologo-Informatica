#ifndef USUARIO_H
#define USUARIO_H

#include <string>
#include "DtClasses.h"

using namespace std;

class Usuario {
protected:
    string nickname;
    string password;
    string fechaNacimiento;
    
public:
    Usuario(string nickname, string password, string fechaNacimiento);
    virtual ~Usuario();
    
    string getNickname();
    virtual DtUsuario getDt() = 0;
};

#endif

