#include <iostream>
#include "Fabrica.h"
#include "DtClasses.h"

using namespace std;

int main() {
    IControlador* controlador = Fabrica::getIControlador();
    
    // Alta de usuario
    DtCliente dtCliente;
    dtCliente.nickname = "juan123";
    dtCliente.fechaNacimiento = "1990-05-15";
    dtCliente.direccion = "Av. Siempreviva 742";
    dtCliente.ciudad = "Springfield";
    
    controlador->altaUsuario(dtCliente, "cliente", "password123", "");
    
    // Listar usuarios
    vector<DtUsuario> usuarios = controlador->listarUsuarios();
    for (auto& u : usuarios) {
        cout << "Usuario: " << u.nickname << endl;
    }
    
    return 0;
}
