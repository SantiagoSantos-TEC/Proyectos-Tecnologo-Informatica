#ifndef COMENTARIO_H
#define COMENTARIO_H

#include "DtClasses.h"
#include <string>
#include <vector>

class Usuario;
class Producto;

class Comentario {
private:
    string texto;
    string fecha;
    Usuario* autor;
    Producto* producto;
    Comentario* padre;
    vector<Comentario*> respuestas;
    
public:
    Comentario(string texto, string fecha, Usuario* autor, Producto* producto, Comentario* padre = nullptr);
    ~Comentario();
    
    void agregarRespuesta(Comentario* c);
    DtComentario getDt();
    
    string getFecha();
    Usuario* getAutor();
    Producto* getProducto();
};

#endif

