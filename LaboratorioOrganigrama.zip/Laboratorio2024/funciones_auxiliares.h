#ifndef FUNCIONES_AUXILIARES_H
#define FUNCIONES_AUXILIARES_H

typedef struct Cargo* Cargos;
typedef char* Cadena;
typedef struct empresas* Empresa;

struct empresas {
	Cargo* cargo_maximo;
};

enum retorno {
	OK,
	ERROR,
	NO_IMPLEMENTADA
};

typedef enum retorno TipoRet;


Cadena crearCadena(const char* palabra);
Cargos buscarCargo(Cargos cargo, Cadena nombreCargo);
void listarJerarquiaAux(Cargos cargo, int nivel);
void eliminarCargo(Cargos cargo);
void mostrarMenu();

#endif
