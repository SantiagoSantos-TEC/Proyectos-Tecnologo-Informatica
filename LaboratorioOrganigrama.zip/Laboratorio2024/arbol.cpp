#include <iostream>
#include <cstring>
#include <strings.h>
#include "arbol.h"
#include "funciones_auxiliares.h"
#define MAX_CARGOS 100
using namespace std;

struct personas {
	Cadena ci;
	Cadena nombre;
	personas* sig;
};

struct Cargo {
	Cadena nombreCargo;
	Cargo* subcargo;       
	Cargo* siguiente;      
	personas* personificacion; 
	Cargo* cargoPadre;     
};

// Funcion para crear el organigrama
TipoRet CrearOrg(Empresa &e, Cadena cargo) {
	if (e->cargo_maximo != NULL) {
		return ERROR;  // Ya existe un organigrama
	}
	Cargo* nuevoCargo = new Cargo();
	nuevoCargo->nombreCargo = crearCadena(cargo);
	nuevoCargo->cargoPadre = NULL;
	nuevoCargo->subcargo = NULL;
	nuevoCargo->siguiente = NULL;
	nuevoCargo->personificacion = NULL;
	e->cargo_maximo = nuevoCargo;
	return OK;
}


// Funcion para insertar un nuevo cargo, pre condicion que haya un organigrama creado
TipoRet NuevoCargo(Empresa &e, Cadena cargoPadre, Cadena nuevoCargo) {
	if (e->cargo_maximo == NULL) {
		return ERROR;  // No hay organigrama
	}
	
	Cargos padre = buscarCargo(e->cargo_maximo, cargoPadre);
	if (padre == NULL) {
		return ERROR;  // Cargo padre no existe
	}
	Cargos nuevo = new Cargo();
	nuevo->nombreCargo = crearCadena(nuevoCargo);
	nuevo->cargoPadre = padre;
	nuevo->subcargo = NULL;
	nuevo->siguiente = padre->subcargo;
	nuevo->personificacion = NULL;
	padre->subcargo = nuevo;
	return OK;
}


// Funcion que lista la jerarquia de la empresa
TipoRet ListarJerarquia(Empresa e) {
	if (e->cargo_maximo == NULL) {
		return ERROR;  // Empresa vacia
	}
	listarJerarquiaAux(e->cargo_maximo, 0); 
	return OK;
}


//Funcion para eliminar un cargo
TipoRet EliminarCargo(Empresa &e, Cadena nombreCargo) {
	if (e->cargo_maximo == NULL) {
		return ERROR;  // La empresa no tiene organigrama
	}
	Cargo* cargoAEliminar = buscarCargo(e->cargo_maximo, nombreCargo);
	if (cargoAEliminar == NULL) {
		return ERROR;  // Cargo no encontrado
	}
	//Si el cargo a eliminar es la raiz de la jerarqu�a
	if (cargoAEliminar == e->cargo_maximo) {
		eliminarCargo(e->cargo_maximo);  
		e->cargo_maximo = NULL;
		return OK;
	}
	// El cargo tiene un padre, buscar y actualizar la jerarquia
	Cargo* padre = cargoAEliminar->cargoPadre;
	if (padre == NULL) {
		return ERROR;  
	}
	// Desconectar el cargo a eliminar de su lista de subcargos/hermanos
	if (padre->subcargo == cargoAEliminar) {
		// Si el cargo a eliminar es el primer subcargo
		padre->subcargo = cargoAEliminar->siguiente;
	} else {
		// Buscar el subcargo anterior en la lista de subcargos
		Cargo* actual = padre->subcargo;
		while (actual != NULL && actual->siguiente != cargoAEliminar) {
			actual = actual->siguiente;
		}
		if (actual != NULL) {
			// Ajustar el puntero para que el siguiente apunte a donde corresponde
			actual->siguiente = cargoAEliminar->siguiente;
		}
	}
	eliminarCargo(cargoAEliminar);
	return OK;
}
	
// Funcion para eliminar todo el organigrama
TipoRet EliminarOrg(Empresa &e) {
	if (e->cargo_maximo == NULL) {
		return ERROR;  // Empresa vac�a
	}	
	eliminarCargo(e->cargo_maximo);
	e->cargo_maximo = NULL;
	return OK;
}



// Funcion auxiliar para recopilar nombres de cargos
int recopilarCargos(Cargos cargo, Cadena* nombres, int i){
	if (cargo == NULL) return i; // Si el cargo es nulo, retornamos i
	// Agregar el nombre del cargo al arreglo
	if (i < MAX_CARGOS) {
		nombres[i] = cargo->nombreCargo;
		i++;
	}
	// Recorrer los subcargos
	Cargos sub = cargo->subcargo;
	while (sub != NULL) {
		i = recopilarCargos(sub, nombres, i); 
		sub = sub->siguiente; 
	}
	return i;
}
	
// Funcion para ordenar los nombres alfabeticamente con burbuja
void ordenarCargos(Cadena* nombres, int contador) {
	for (int i = 0; i < contador - 1; i++) {
		for (int j = 0; j < contador - i - 1; j++) {
			if (strcasecmp(nombres[j], nombres[j + 1]) > 0) {
				Cadena temp = nombres[j];
				nombres[j] = nombres[j + 1];
				nombres[j + 1] = temp;
			}
		}
	}
}
	
// Funcion para listar los cargos en orden alfabetico
TipoRet ListarCargosAlf(Empresa e) {
	if (e == NULL || e->cargo_maximo == NULL) {
		return ERROR;  // La empresa esta vac�a
	}	
	Cadena nombres[MAX_CARGOS]; 
	// Recopilar nombres de cargos a partir de la jerarquia
	int count = recopilarCargos(e->cargo_maximo, nombres, 0);
	// Ordenar los nombres alfabeticamente
	ordenarCargos(nombres, count);
	// Imprimir la lista de nombres ordenados
	cout << "Listado de Cargos en Orden Alfabetico:" << endl;
	for (int i = 0; i < count; i++) {
		cout << nombres[i] << endl;
	}
	return OK;
}

//Funcion para listar los cargos antecesores al cargo indicado
TipoRet ListarSuperCargos(Empresa e, Cadena nom_cargo) {
	if (e == NULL || e->cargo_maximo == NULL) {
		return ERROR;  
	}
	Cargos cargoActual = buscarCargo(e->cargo_maximo, nom_cargo);
	if (cargoActual == NULL) {
		return ERROR;  
	}
	Cadena cargosSuperiores[MAX_CARGOS];
	int contador = 0;
	// Recorremos hacia arriba hasta llegar a la jerarquia maxima
	while (cargoActual != NULL) {
		if (contador < MAX_CARGOS) {
			cargosSuperiores[contador++] = cargoActual->nombreCargo;
		}
		cargoActual = cargoActual->cargoPadre; 
	}
	// Imprimir los cargos en orden inverso
	cout << "Cargos que anteceden a " << nom_cargo << ":" << endl;
	for (int i = contador - 1; i >= 0; i--) {
		cout << cargosSuperiores[i];
		if (i > 0) {
			cout << " - ";
		}
	}
	cout << endl;
	return OK;
}




