#ifndef LISTA_H
#define LISTA_H
#include <iostream>
#include <cstring>
#include <strings.h>
#include "funciones_auxiliares.h"



TipoRet CrearOrg(Empresa &e, Cadena cargo);
TipoRet NuevoCargo(Empresa &e, Cadena cargoPadre, Cadena nuevoCargo);
TipoRet ListarJerarquia(Empresa e);
TipoRet EliminarCargo(Empresa &e, Cadena cargo);
TipoRet EliminarOrg(Empresa &e);
TipoRet ListarCargosAlf(Empresa e);
TipoRet ListarSuperCargos(Empresa e, Cadena nom_cargo);

//funciones de listas

TipoRet AsignarPersona(Empresa &e, Cadena cargo, Cadena nom, Cadena ci);
TipoRet EliminarPersona(Empresa &e, Cadena ci);
TipoRet ReasignarPersona(Empresa &e, Cadena nuevoCargo, Cadena ci);
TipoRet ListarPersonas(Empresa e, Cadena cargo);


#endif
