#include <iostream>
#include <cstring>
#include <strings.h>
#include "lista.h"
#include "funciones_auxiliares.h"
using namespace std;

struct Cargo {
	Cadena nombreCargo;
	Cargo* subcargo;       
	Cargo* siguiente;      
	personas* personificacion; 
	Cargo* cargoPadre;     
};

struct personas {
	Cadena ci;
	Cadena nombre;
	personas* sig;
};

// Funcion auxiliar para crear cadenas 
Cadena crearCadena(const char* palabra) {
	Cadena nuevaCadena = new char[strlen(palabra) + 1];
	strcpy(nuevaCadena, palabra);
	return nuevaCadena;
}

// Funcion para buscar un cargo por su nombre
Cargos buscarCargo(Cargos cargo, Cadena nombreCargo) {
	if (strcasecmp(cargo->nombreCargo, nombreCargo) == 0) {
		return cargo;
	}
	Cargos sub = cargo->subcargo;
	while (sub != NULL) {
		Cargos encontrado = buscarCargo(sub, nombreCargo);
		if (encontrado != NULL) {
			return encontrado;
		}
		sub = sub->siguiente;
	}
	return NULL;
}

// Funcion auxiliar para listar la jerarquia con precondicion de que tiene que haber un organigrama creado
void listarJerarquiaAux(Cargos cargo, int nivel) {
	if (cargo == NULL) return;
	for (int i = 0; i < nivel; i++) {
		cout << "	";
	}
	cout << cargo->nombreCargo<< endl;
	Cargos sub = cargo->subcargo;
	while (sub != NULL) {
		listarJerarquiaAux(sub, nivel + 1);
		sub = sub->siguiente;
	}
}

// Funcion auxiliar para eliminar un cargo y sus subcargos
void eliminarCargo(Cargos cargo) {
	Cargos sub = cargo->subcargo;
	while (sub != NULL) {
		Cargos siguiente = sub->siguiente;
		eliminarCargo(sub);
		sub = siguiente;
	}
	delete cargo->nombreCargo;
	Persona p = cargo->personificacion;
	while (p != NULL) {
		Persona siguienteP = p->sig;
		delete p->ci;
		delete p->nombre;
		delete p;
		p = siguienteP;
	}
	delete cargo;
}

//Menu
void mostrarMenu() {
	cout << "        Menu        " << endl;
	cout << "--------------------" << endl;
	cout <<endl<< "1. Crear organigrama" << endl;
	cout << "2. Eliminar organigrama" << endl;
	cout << "3. Crear un nuevo cargo" << endl;
	cout << "4. Eliminar un cargo" << endl;
	cout << "5. Listar cargos alfabeticamente" << endl;
	cout << "6. Listar jerarquia" << endl;
	cout << "7. Asignar persona a un cargo" << endl;
	cout << "8. Eliminar persona" << endl;
	cout << "9. Reasignar persona" << endl;
	cout << "10. Listar personas" << endl;
	cout << "11. Listar supercargos" << endl;
	cout << "12. Salir" << endl;
	cout <<endl<< "Seleccione una opcion: ";
}

//Funcion auxiliar para probar el codigo
//void poblarEmpresa(Empresa &e) {
//	CrearOrg(e, "Decano");
//	NuevoCargo(e, "Decano", "Secretario academico");
//	NuevoCargo(e, "Secretario academico", "Coordinador");
//	NuevoCargo(e, "Coordinador", "Coordinador adjunto");
//	NuevoCargo(e, "Coordinador adjunto", "Bedel");
//	AsignarPersona(e, "Decano", "Empleado1", "1");
//	AsignarPersona(e, "Secretario academico", "Empleado2", "2");
//	AsignarPersona(e, "Coordinador", "Empleado3", "3");
//	AsignarPersona(e, "Coordinador adjunto", "Empleado4", "4");
//	AsignarPersona(e, "Bedel", "Empleado5", "5");
//}
