#include <iostream>
#include <cstring>
#include <strings.h>
#include "arbol.h"


using namespace std;

int main() {
	Empresa e= new empresas;
	e->cargo_maximo = NULL;
	int opcion;
	char cargoPadre[100], nuevoCargo[100], nombre[100], ci[10];
	bool salir = false;
/*	poblarEmpresa(e);	*/	//Funcion para probar el codigo
	while (!salir) {
		mostrarMenu();
		cin >> opcion;
		cin.ignore();  		
		switch (opcion) {
		case 1:
			cout << "Ingrese el nombre del cargo maximo del organigrama: ";
			cin.getline(cargoPadre, 100);
			if (CrearOrg(e, crearCadena(cargoPadre)) == OK) {
				cout << "Organigrama creado exitosamente.\n";
			} else {
				cout << "Error: Ya existe un organigrama.\n";
			}
			break;
		case 2:
			if (EliminarOrg(e) == OK) {
				cout << "Organigrama eliminado correctamente.\n";
			} else {
				cout << "Error: No hay organigrama para eliminar.\n";
			}
			break;
		case 3:
			if(e->cargo_maximo!=NULL){
				cout << "Ingrese el cargo padre: ";
				cin.getline(cargoPadre, 100);
				cout << "Ingrese el nuevo cargo: ";
				cin.getline(nuevoCargo, 100);
				if (NuevoCargo(e, crearCadena(cargoPadre), crearCadena(nuevoCargo)) == OK) {
					cout << "Nuevo cargo aniadido correctamente.\n";
				} else {
					cout << "Error: No se pudo aniadir el cargo.\n";
				}
				break;
			}
			cout<<"Error: No hay organigrama disponible"<<endl;
			break;
		case 4: 
			if(e->cargo_maximo!=NULL){
				cout << "Ingrese el cargo a eliminar: ";
				cin.getline(nombre, 100);
				if (EliminarCargo(e, crearCadena(nombre)) == OK) {
					cout << "Cargo eliminado exitosamente.\n";
				} else {
					cout << "Error: No se encontro el cargo.\n";
				}
				break;
			}
			cout<<"Error: No hay organigrama disponible"<<endl;
			break;
		case 5:
			
			if (ListarCargosAlf(e) == ERROR) {
				cout << "Error: No hay organigrama disponible.\n";
			}
			break;
		case 6:
			if(e->cargo_maximo!=NULL){
				cout << "Jerarquia actual:\n";
				if (e->cargo_maximo==NULL || ListarJerarquia(e) == ERROR) {
					cout << "Error: No hay organigrama disponible.\n";
				}
			break;
			}
			cout<<"Error: No hay organigrama disponible"<<endl;
			break;
		case 7:
			if(e->cargo_maximo!=NULL){
				cout << "Ingrese el nombre del cargo donde asignar la persona: ";
				cin.getline(cargoPadre, 100);
				cout << "Ingrese el nombre de la persona: ";
				cin.getline(nombre, 100);
				cout << "Ingrese la CI de la persona: ";
				cin.getline(ci, 10);
				if (AsignarPersona(e, crearCadena(cargoPadre), crearCadena(nombre), crearCadena(ci)) == OK) {
					cout << "Persona asignada exitosamente.\n";
				} else {
					cout << "Error: No se pudo asignar la persona.\n";
				}
				break;
			}
			cout<<"Error: No hay organigrama disponible"<<endl;
			break;
		case 8:
			if(e->cargo_maximo!=NULL){
				cout << "Ingrese la CI de la persona a eliminar: ";
				cin.getline(ci, 10);
				if (EliminarPersona(e, crearCadena(ci)) == OK) {
					cout << "Persona eliminada exitosamente.\n";
				} else {
					cout << "Error: No se encontro a la persona.\n";
				}
				break;
			}
			cout<<"Error: No hay organigrama disponible"<<endl;
			break;
		case 9:
			if(e->cargo_maximo!=NULL){
				cout << "Ingrese la ci de la persona a reasignar: ";
				cin.getline(ci, 10);
				cout << "Ingrese el cargo nuevo: ";
				cin.getline(nombre, 100);
				if (ReasignarPersona(e, crearCadena(nombre), crearCadena(ci)) == ERROR) {
					cout << "No se pudo reasignar.\n";
				}else{
					cout << "Persona reasignada con exito.\n";
				}
				break;
			}
			cout<<"Error: No hay organigrama disponible"<<endl;
			break;
		case 10:
			if(e->cargo_maximo!=NULL){
				cout<<"Ingrese el cargo a listar: ";
				cin.getline(cargoPadre, 100);
				ListarPersonas(e, cargoPadre);
				break;
			}
			cout<<"Error: No hay organigrama disponible"<<endl;
			break;
		case 11:
			if(e->cargo_maximo!=NULL){
				cout << "Ingrese el super cargo a listar: ";
				cin.getline(nombre, 100);
				if (ListarSuperCargos(e, crearCadena(nombre)) == ERROR) {
					cout << "Cargo no encontrado.\n";
				}
				break;
			}
			cout<<"Error: No hay organigrama disponible"<<endl;
			break;
		case 12:
			salir = true;
			break;
			
		default:
			cout << "Opcion no valida, por favor intente de nuevo.\n";
			break;
		}
		cout<<endl<<"Presione ENTER para continuar";
		getchar();
		system("clear");
	}
	return 0;
}
