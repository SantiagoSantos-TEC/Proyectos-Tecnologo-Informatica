#include <iostream>
#include <cstring>
#include <strings.h>
#include "lista.h"
#include "funciones_auxiliares.h"
#include "arbol.h"
using namespace std;

struct personas {
	Cadena ci;
	Cadena nombre;
	personas* sig;
};

struct Cargo {
	Cadena nombreCargo;
	Cargo* subcargo;       
	Cargo* siguiente;      
	personas* personificacion; 
	Cargo* cargoPadre;     
};

// Funcion para asignar una persona a un cargo
TipoRet AsignarPersona(Empresa &e, Cadena cargo, Cadena nom, Cadena ci) {
	Cargos c = buscarCargo(e->cargo_maximo, cargo);
	if (c == NULL) {
		return ERROR;  // Cuando no se encontro el cargo
	}
	// Verificar que la persona no este asignada
	Persona p = c->personificacion;
	while (p != NULL) {
		if (strcmp(p->ci, ci) == 0) {
			return ERROR;  // Persona ya asignada
		}
		p = p->sig;
	}
	// Asignar nueva persona
	Persona nuevaPersona = new personas();
	nuevaPersona->ci = crearCadena(ci);
	nuevaPersona->nombre = crearCadena(nom);
	nuevaPersona->sig= c->personificacion;
	c->personificacion = nuevaPersona;
	
	return OK;
}

// Funci�n para eliminar una persona de un cargo precondicion tienen que existir personas
TipoRet EliminarPersona(Empresa &e, Cadena ci) {
	if (e->cargo_maximo == NULL) {
		return ERROR;  // Empresa vac�a
	}
	Cargos cargo = e->cargo_maximo;
	while (cargo != NULL) {
		Persona p = cargo->personificacion;
		Persona anterior = NULL;
		while (p != NULL) {
			if (strcmp(p->ci, ci) == 0) {
				if (anterior == NULL) {
					cargo->personificacion = p->sig;
				} else {
					anterior->sig = p->sig;
				}
				delete p->ci;
				delete p->nombre;
				delete p;
				return OK;
			}
			anterior = p;
			p = p->sig;
		}
		cargo = cargo->subcargo;
	}
	return OK;
}

//Funcion para listar personas de un determinado cargo, dicho cargo debe tener personas asignadas y existir
TipoRet ListarPersonas(Empresa e, Cadena cargo) {
	if (e->cargo_maximo == NULL) {
		printf("Empresa vacia\n");
		return ERROR; // La empresa esta vacia
	}
	Cargos c = buscarCargo(e->cargo_maximo, cargo);
	if (c == NULL) {
		printf("El cargo no existe\n");
		return ERROR; // El cargo no existe
	}else if (c->personificacion == NULL) {
		printf("No hay personas asignadas al cargo %s\n", cargo);
		return ERROR;
	}
	printf("Listado de personas asignadas a %s\n", cargo);
	printf("---------------------------------------\n");
	Persona p = c->personificacion; 
	while (p != NULL) {
		printf("%s - %s\n", p->ci, p->nombre);
		p = p->sig;
	}
	return OK;
}

// Funcion auxiliar que busca la persona en toda la jerarquia
Persona buscarPersonaEnJerarquia(Cargos cargo, Cadena ci, Cargos &cargoOrigen) {
	while (cargo != NULL) {
		Persona p = cargo->personificacion;
		
		while (p != NULL) {
			if (strcmp(p->ci, ci) == 0) {
				cargoOrigen = cargo;
				return p;
			}
			
			p = p->sig;
		}
		Persona personaEncontrada = buscarPersonaEnJerarquia(cargo->subcargo, ci, cargoOrigen);
		if (personaEncontrada != NULL) {
			return personaEncontrada;
		}
		cargo = cargo->siguiente;
	}
	return NULL;
}

//Funcion para reasignar una persona a un cargo especificado, debe existir la persona y su nuevo cargo
TipoRet ReasignarPersona(Empresa &e, Cadena nuevoCargo, Cadena ci) {
	if (e == NULL || e->cargo_maximo == NULL) {
		return ERROR;  
	}
	Cargos cargoDestino = buscarCargo(e->cargo_maximo, nuevoCargo);
	if (cargoDestino == NULL) {
		return ERROR; 
	}
	Cargos cargoOrigen = NULL;
	Persona personaAReasignar = NULL;
	personaAReasignar = buscarPersonaEnJerarquia(e->cargo_maximo, ci, cargoOrigen);
	if (personaAReasignar == NULL) {
		return ERROR; 
	}
	Persona p = cargoDestino->personificacion;
	while (p != NULL) {
		if (strcmp(p->ci, ci) == 0) {
			return ERROR;  
		}
		p = p->sig;
	}
	// Eliminar la persona del cargo original
	if (cargoOrigen != NULL) {
		Persona anterior = NULL;
		Persona actual = cargoOrigen->personificacion;
		while (actual != NULL) {
			if (strcmp(actual->ci, ci) == 0) {
				if (anterior == NULL) {
					cargoOrigen->personificacion = actual->sig;
				} else {
					anterior->sig = actual->sig;
				}
				break;  // Persona eliminada del cargo original
			}
			anterior = actual;
			actual = actual->sig;
		}
	}
	// Asignar la persona al nuevo cargo
	personaAReasignar->sig = cargoDestino->personificacion;
	cargoDestino->personificacion = personaAReasignar;
	return OK;
}
