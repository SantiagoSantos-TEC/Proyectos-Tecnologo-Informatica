#ifndef LISTA_H
#define LISTA_H
#include "funciones_auxiliares.h"
#include <iostream>
#include <cstring>
#include <strings.h>

typedef struct personas* Persona;


//TipoRet AsignarPersona(Empresa &e, Cadena cargo, Cadena nom, Cadena ci);
//TipoRet EliminarPersona(Empresa &e, Cadena ci);
//TipoRet ReasignarPersona(Empresa &e, Cadena nuevoCargo, Cadena ci);
//TipoRet ListarPersonas(Empresa e, Cadena cargo);

#endif
